/**
 * @Author:
 * @Date: 2024-08-07 17:55:39
 * @LastEditors: 
 * @LastEditTime: 2024-08-14 21:12:58
 * @FilePath: src/main/java/abstraction/main/Main.java
 * @Description: 这是默认设置, 可以在设置》工具》File Description中进行配置
 */
package abstraction.main;

import abstraction.bean.Car;
import abstraction.bean.Volvo;
import abstraction.bean.BMW;

public class Main {
    public static void main(String[] args) {

        //Abstraction_BMW.A a= new Abstraction_BMW().new A();
        BMW.A  a = new BMW.A();
        
        
        Car bmw = new BMW();
        bmw.startAndSpeedUp();

        Volvo v = new Volvo();
        //v.run();

        Car[] cars = {v};
        startAllCars(cars);
        
        class c3 extends Car {

            @Override
            public void start() {

            }

            @Override
            public void stop() {

            }

            @Override
            public void speedUp() {

            }
        };

        Car c1 = new Car(){


            @Override
            public void start() {
                
            }

            @Override
            public void stop() {

            }

            @Override
            public void speedUp() {

            }
        };


        Car c2 = new Car(){

            @Override
            public void start() {

            }

            @Override
            public void stop() {

            }

            @Override
            public void speedUp() {

            }
        };

    }

    public static void startAllCars(Car[] cars) {
        for (int i = 0; i < cars.length; i++) {
            cars[i].start();
        }
    }


}
