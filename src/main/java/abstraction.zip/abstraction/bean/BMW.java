/**
 * @Author:
 * @Date: 2024-08-07 18:28:32
 * @LastEditors: 
 * @LastEditTime: 2024-08-14 21:12:58
 * @FilePath: src/main/java/abstraction/bean/BMW.java
 * @Description: 这是默认设置, 可以在设置》工具》File Description中进行配置
 */
package abstraction.bean;

public class BMW extends Car {
    
    public static class A{
        
    }
    
    public void start() {
        System.out.println("BMW start");
    }

    public void stop() {
        System.out.println("BMW stop");
    }

    public void speedUp() {
        System.out.println("BMW speed up");
    }
}
