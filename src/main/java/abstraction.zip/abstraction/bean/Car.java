/**
 * @Author:
 * @Date: 2024-08-07 18:33:36
 * @LastEditors: 
 * @LastEditTime: 2024-08-14 21:12:58
 * @FilePath: src/main/java/abstraction/bean/Car.java
 * @Description: 这是默认设置, 可以在设置》工具》File Description中进行配置
 */
package abstraction.bean;

public abstract class Car {
    
    public abstract void start();

    public abstract void stop();

    public abstract void speedUp();

    public void startAndSpeedUp(){
        start();
        speedUp();
    }
}
